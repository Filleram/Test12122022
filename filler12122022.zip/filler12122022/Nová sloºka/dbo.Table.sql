﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [FirstName] TEXT NULL, 
    [LastName] TEXT NULL, 
    [Phone] TEXT NULL, 
    [Email] TEXT NULL, 
    [BirthDate] DATETIME NULL
)
